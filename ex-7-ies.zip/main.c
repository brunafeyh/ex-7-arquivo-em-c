/*7. Fac¸a um programa que receba do usuario um arquivo texto. Crie outro arquivo texto ´
contendo o texto do arquivo de entrada, mas com as vogais substitu´ıdas por ‘*’.

BRUNA CAROLINA DA SILVA FEYH 
22/08/2023
*/
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

#define MAX 1000000

void trocar(char *c, char s){
    *c = s;
}

int isvogal(char c){
    char vogais[] = "aeiouAEIOU";

    if (strchr(vogais, c) != NULL) {
        return 1; // é uma vogal
    } else {
        return 0; // É uma consoante.
    }
}

void getnovastring(char str[], int n){
    int i;
    for(i=0; i<n; i++){
        if(isvogal(str[i])){
            trocar(&str[i], '*');
        }
    }
}


int parq(char *s, char str[]){
    FILE *f;
    f = fopen(s, "w");
    if(f == NULL) return errno;
    
    fprintf(f, "%s", str);
 
    fclose(f);
    return 0;
}
int lerarq(char *s, char str[]){
    FILE *f;
    f = fopen(s, "r");
    if(f == NULL) return errno;
    
    fscanf(f, "%[^EOF]", str);
 
    fclose(f);
    return 0;
}
int main()
{
    char ch[MAX];

    int erro, tam;
    
    erro = lerarq("arq.txt", ch);
    if(erro != 0) printf("erro de leitura: %d\n", erro);
    
    tam = strlen(ch);
    
    getnovastring(ch, tam);
    
    erro = parq("saida.txt", ch);
    if(erro != 0) printf("erro de gravação: %d\n", erro);
    
   
    return 0;
}
